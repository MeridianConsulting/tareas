<?php
/**
 * Script de diagnóstico para identificar problemas en producción
 * Acceder a: https://control.meridianltda.com/api/v1/debug.php
 * IMPORTANTE: Eliminar este archivo después de diagnosticar el problema
 */

header('Content-Type: application/json');

$diagnostics = [
    'timestamp' => date('Y-m-d H:i:s'),
    'php_version' => PHP_VERSION,
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'checks' => []
];

// Verificar autoloader
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
$diagnostics['checks']['autoloader'] = [
    'exists' => file_exists($autoloadPath),
    'path' => $autoloadPath,
    'readable' => file_exists($autoloadPath) ? is_readable($autoloadPath) : false
];

// Verificar archivo de configuración
$configPath = __DIR__ . '/../src/Config/config.php';
$diagnostics['checks']['config'] = [
    'exists' => file_exists($configPath),
    'path' => $configPath,
    'readable' => file_exists($configPath) ? is_readable($configPath) : false
];

// Verificar .env
$envPath = __DIR__ . '/../.env';
$diagnostics['checks']['env'] = [
    'exists' => file_exists($envPath),
    'path' => $envPath,
    'readable' => file_exists($envPath) ? is_readable($envPath) : false
];

// Verificar directorio de logs
$logsPath = __DIR__ . '/../storage/logs';
$diagnostics['checks']['logs_directory'] = [
    'exists' => is_dir($logsPath),
    'path' => $logsPath,
    'writable' => is_dir($logsPath) ? is_writable($logsPath) : false
];

// Intentar cargar autoloader
if (file_exists($autoloadPath)) {
    try {
        require_once $autoloadPath;
        $diagnostics['checks']['autoloader_load'] = ['success' => true];
    } catch (\Throwable $e) {
        $diagnostics['checks']['autoloader_load'] = [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

// Intentar cargar configuración
if (file_exists($configPath)) {
    try {
        require $configPath;
        $diagnostics['checks']['config_load'] = ['success' => true];
        
        // Verificar constantes importantes
        $diagnostics['constants'] = [
            'APP_ENV' => defined('APP_ENV') ? APP_ENV : 'NOT_DEFINED',
            'APP_DEBUG' => defined('APP_DEBUG') ? (APP_DEBUG ? 'true' : 'false') : 'NOT_DEFINED',
            'DB_HOST' => defined('DB_HOST') ? DB_HOST : 'NOT_DEFINED',
            'DB_NAME' => defined('DB_NAME') ? DB_NAME : 'NOT_DEFINED',
            'JWT_SECRET' => defined('JWT_SECRET') ? (strlen(JWT_SECRET) > 0 ? 'SET' : 'EMPTY') : 'NOT_DEFINED',
            'CORS_ORIGIN' => defined('CORS_ORIGIN') ? CORS_ORIGIN : 'NOT_DEFINED',
        ];
        
        // Intentar conectar a la base de datos
        if (defined('DB_HOST') && defined('DB_NAME')) {
            try {
                $dsn = sprintf(
                    'mysql:host=%s;dbname=%s;charset=utf8mb4',
                    DB_HOST,
                    DB_NAME
                );
                $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_TIMEOUT => 5
                ]);
                $diagnostics['checks']['database'] = ['success' => true, 'connected' => true];
            } catch (\PDOException $e) {
                $diagnostics['checks']['database'] = [
                    'success' => false,
                    'error' => $e->getMessage()
                ];
            }
        }
        
    } catch (\Throwable $e) {
        $diagnostics['checks']['config_load'] = [
            'success' => false,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];
    }
}

// Verificar extensiones PHP necesarias
$requiredExtensions = ['pdo', 'pdo_mysql', 'json', 'mbstring'];
$diagnostics['php_extensions'] = [];
foreach ($requiredExtensions as $ext) {
    $diagnostics['php_extensions'][$ext] = extension_loaded($ext);
}

// Verificar permisos de archivos importantes
$importantFiles = [
    'index.php' => __DIR__ . '/index.php',
    'routes.php' => __DIR__ . '/../src/Config/routes.php',
];

$diagnostics['file_permissions'] = [];
foreach ($importantFiles as $name => $path) {
    if (file_exists($path)) {
        $diagnostics['file_permissions'][$name] = [
            'readable' => is_readable($path),
            'writable' => is_writable($path),
            'permissions' => substr(sprintf('%o', fileperms($path)), -4)
        ];
    } else {
        $diagnostics['file_permissions'][$name] = ['exists' => false];
    }
}

echo json_encode($diagnostics, JSON_PRETTY_PRINT);

