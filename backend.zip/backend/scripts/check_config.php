<?php
/**
 * Script de verificación de configuración
 * Ejecutar desde la línea de comandos: php scripts/check_config.php
 */

echo "=== Verificación de Configuración del Backend ===\n\n";

$errors = [];
$warnings = [];

// 1. Verificar archivo .env
echo "1. Verificando archivo .env...\n";
if (!file_exists(__DIR__ . '/../.env')) {
    $errors[] = "❌ Archivo .env no encontrado";
} else {
    echo "   ✅ Archivo .env existe\n";
    
    // Cargar .env
    try {
        require_once __DIR__ . '/../vendor/autoload.php';
        $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
        $dotenv->load();
    } catch (Exception $e) {
        $errors[] = "❌ Error al cargar .env: " . $e->getMessage();
    }
}

// 2. Verificar variables críticas
echo "\n2. Verificando variables de entorno...\n";

$requiredVars = [
    'DB_HOST' => 'Host de base de datos',
    'DB_NAME' => 'Nombre de base de datos',
    'DB_USER' => 'Usuario de base de datos',
    'JWT_SECRET' => 'Secreto JWT',
    'CORS_ORIGIN' => 'Origen CORS',
];

foreach ($requiredVars as $var => $desc) {
    $value = $_ENV[$var] ?? null;
    if (empty($value)) {
        $errors[] = "❌ $var ($desc) no está configurado";
    } else {
        // Ocultar valores sensibles
        if (in_array($var, ['DB_PASS', 'JWT_SECRET', 'APP_KEY'])) {
            $display = str_repeat('*', min(strlen($value), 20));
        } else {
            $display = $value;
        }
        echo "   ✅ $var: $display\n";
    }
}

// 3. Verificar JWT_SECRET
if (isset($_ENV['JWT_SECRET'])) {
    if (strlen($_ENV['JWT_SECRET']) < 32) {
        $warnings[] = "⚠️  JWT_SECRET es muy corto (mínimo 32 caracteres recomendado)";
    } else {
        echo "   ✅ JWT_SECRET tiene longitud adecuada\n";
    }
}

// 4. Verificar APP_KEY
if (isset($_ENV['APP_KEY'])) {
    if (strlen($_ENV['APP_KEY']) < 32) {
        $warnings[] = "⚠️  APP_KEY es muy corto (mínimo 32 caracteres recomendado)";
    } else {
        echo "   ✅ APP_KEY tiene longitud adecuada\n";
    }
}

// 5. Verificar conexión a base de datos
echo "\n3. Verificando conexión a base de datos...\n";
try {
    require __DIR__ . '/../src/Config/config.php';
    $db = \App\Core\Database::getInstance()->getConnection();
    $db->query('SELECT 1');
    echo "   ✅ Conexión a base de datos exitosa\n";
} catch (Exception $e) {
    $errors[] = "❌ Error de conexión a base de datos: " . $e->getMessage();
}

// 6. Verificar vendor/autoload.php
echo "\n4. Verificando dependencias de Composer...\n";
if (!file_exists(__DIR__ . '/../vendor/autoload.php')) {
    $errors[] = "❌ vendor/autoload.php no encontrado. Ejecuta: composer install";
} else {
    echo "   ✅ vendor/autoload.php existe\n";
}

// 7. Verificar directorio de logs
echo "\n5. Verificando directorio de logs...\n";
$logPath = __DIR__ . '/../storage/logs';
if (!is_dir($logPath)) {
    $warnings[] = "⚠️  Directorio storage/logs no existe";
    if (!mkdir($logPath, 0755, true)) {
        $errors[] = "❌ No se pudo crear el directorio storage/logs";
    } else {
        echo "   ✅ Directorio storage/logs creado\n";
    }
} else {
    echo "   ✅ Directorio storage/logs existe\n";
    if (!is_writable($logPath)) {
        $warnings[] = "⚠️  Directorio storage/logs no es escribible";
    } else {
        echo "   ✅ Directorio storage/logs es escribible\n";
    }
}

// 8. Verificar archivos críticos
echo "\n6. Verificando archivos críticos...\n";
$criticalFiles = [
    'public/index.php' => 'Punto de entrada principal',
    'public/.htaccess' => 'Configuración de Apache',
    'src/Config/config.php' => 'Archivo de configuración',
    'src/Config/routes.php' => 'Archivo de rutas',
];

foreach ($criticalFiles as $file => $desc) {
    $path = __DIR__ . '/../' . $file;
    if (!file_exists($path)) {
        $errors[] = "❌ $file ($desc) no encontrado";
    } else {
        echo "   ✅ $file existe\n";
    }
}

// 9. Verificar CORS_ORIGIN
echo "\n7. Verificando configuración CORS...\n";
if (isset($_ENV['CORS_ORIGIN'])) {
    $corsOrigin = $_ENV['CORS_ORIGIN'];
    if (substr($corsOrigin, -1) === '/') {
        $warnings[] = "⚠️  CORS_ORIGIN no debe terminar con '/' (actual: $corsOrigin)";
    }
    if (!filter_var($corsOrigin, FILTER_VALIDATE_URL)) {
        $warnings[] = "⚠️  CORS_ORIGIN no parece ser una URL válida: $corsOrigin";
    } else {
        echo "   ✅ CORS_ORIGIN es una URL válida: $corsOrigin\n";
    }
}

// Resumen
echo "\n" . str_repeat("=", 50) . "\n";
echo "RESUMEN:\n";
echo str_repeat("=", 50) . "\n";

if (empty($errors) && empty($warnings)) {
    echo "✅ ¡Todo está configurado correctamente!\n";
    exit(0);
}

if (!empty($warnings)) {
    echo "\n⚠️  ADVERTENCIAS:\n";
    foreach ($warnings as $warning) {
        echo "   $warning\n";
    }
}

if (!empty($errors)) {
    echo "\n❌ ERRORES (deben corregirse):\n";
    foreach ($errors as $error) {
        echo "   $error\n";
    }
    exit(1);
}

exit(0);

